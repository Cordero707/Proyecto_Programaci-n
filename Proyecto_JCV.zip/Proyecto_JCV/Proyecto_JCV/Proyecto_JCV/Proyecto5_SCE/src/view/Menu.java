package view;


import java.util.Scanner;

import model.Curso;
import model.Instructor;
import service.Inscripcion;

 

public class Menu {

    public static void main (String[] args) throws Exception {
        Scanner scan = new Scanner (System.in);

        Instructor instructor = null;
        int opcion = 0;
        String menu = ("\n1 Guardar Curso\n2 Guardar Instructor\n3 Guardar Inscripcion\n4 Mostrar Curso");
        
        do {
            System.out.println(menu);
             opcion = scan.nextInt();
        

        switch (opcion) {
            case 1:
                Curso curso = new Curso();
                int idCurso;
                String descripcion;
                int horas;
                int precio;

                System.out.println("Indique el ID del curso");
                idCurso = scan.nextInt();
                curso.setIdICurso(idCurso);

                System.out.println("Indique la descripción del curso");
                descripcion = scan.next();
                curso.setDescripcion(descripcion);

                System.out.println("Indique las horas totales del curso");
                horas = scan.nextInt();
                curso.setHoras(horas);

                System.out.println("Indique el precio del curso");
                precio = scan.nextInt();
                curso.setPrecio(precio);
                break;
        
                case 2:
                Instructor instructor = new Instructor();
                int idInstructor;
                String nombre;
                int edad;
                boolean activo;

                System.out.println("Indique el ID del instructor");
                idInstructor = scan.nextInt();
                instructor.setIdInstructor(idInstructor);

                System.out.println("Indique el nombre del instructor");
                nombre = scan.next();
                instructor.setNombre(nombre);

                System.out.println("Indique la edad del instructor");
                edad = scan.nextInt();
                instructor.setEdad(edad);

                System.out.println("Indique si el instructor esta activo (true/false)");
                activo = scan.nextBoolean();
                instructor.setActivo(activo);
                break;

                case 3:
                Inscripcion inscripcion = new Inscripcion();
                int idInscripcion;
                String nombre1;
                int cobro;

                System.out.println("Indique el ID de la inscripción");
                idInscripcion = scan.nextInt();
                inscripcion.setIdInscripcion(idInscripcion);

                System.out.println("Indique el nombre de la persona que hace la inscripcion");
                nombre1 = scan.next();
                inscripcion.setNombre1(nombre1);

                System.out.println("Indique el monto total de la inscripcion");
                cobro = scan.nextInt();
                inscripcion.setCobro(cobro);
                break;

                case 4:
                   if (instructor!= null) {
                        System.out.println("La info del instructor es" + instructor.mostrarInfo());
                   }

                   
                    break;

                case 5:

                System.out.println( "Saliendo del sistema...");

                    break;

            default:
                break;
        }
    } while (opcion != 7);

        scan.close();

    
    }
}