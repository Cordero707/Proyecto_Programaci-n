package model;

public class Curso {
    private int idCurso;
    private String descripcion;
    private int horas;
    private int precio;


public Curso() {
    
}

public Curso(int idCurso, String descripcion, int horas, int precio){
    this.idCurso = idCurso;
    this.descripcion = descripcion;
    this.horas = horas;
    this.precio = precio;
}

public int getIdCurso() {
    return this.idCurso;
}

public void setIdICurso(int idCurso) {
    this.idCurso = idCurso;
}

public String getDescripcion() {
    return this.descripcion;
}

public void setDescripcion(String descripcion) {
    this.descripcion = descripcion;
}

public int getHoras() {
    return this.horas;
}

public void setHoras(int horas) {
    this.horas = horas;
}

public int getPrecio() {
    return this.precio;
}

public void setPrecio(int precio) {
    this.precio = precio;
}

public String mostrarInfor(){
    return "IdCurso: " + getDescripcion() + "\nDescripción: " + getDescripcion() + "\nHoras: " + getHoras() + "\nPrecio: " + getPrecio();
}

}
