package model;

public class Instructor {
    private int idInstructor;
    private String nombre;
    private int edad;
    private boolean activo;


public Instructor() {

}

public int getIdInstructor() {
    return this.idInstructor;
}

public void setIdInstructor(int idInstructor) {
    this.idInstructor = idInstructor;
}

public String getNombre() {
    return this.nombre;
}

public void setNombre(String nombre) {
    this.nombre = nombre;
}

public int getEdad() {
    return this.edad;
}

public void setEdad(int edad) {
    this.edad = edad;
}

public boolean getActivo() {
    return this.activo;
}

public void setActivo(boolean activo) {
    this.activo = activo;
}
}