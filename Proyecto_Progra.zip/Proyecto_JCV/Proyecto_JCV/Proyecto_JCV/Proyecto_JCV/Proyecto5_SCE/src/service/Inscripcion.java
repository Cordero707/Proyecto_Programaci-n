package service;

import model.Curso;
import model.Instructor;

public class Inscripcion {
    
    private int idInscripcion;
    private String nombre1;
    private int cobro;
    private Curso curso;
    private Instructor instructor;


public Inscripcion() {

}

public Inscripcion (int idInscripcion, String nombre1, int cobro, Curso curso, Instructor instructor){
    this.instructor = instructor;
    this.nombre1 = nombre1;
    this.cobro = cobro;
    this.curso = curso;
}

public int getIdInscripcion() {
    return this.idInscripcion;
}

public void setIdInscripcion(int idInscripcion) {
    this.idInscripcion = idInscripcion;
}

public String getNombre1() {
    return this.nombre1;
}

public void setNombre1(String nombre1) {
    this.nombre1 = nombre1;
}

public int getCobro() {
    return this.cobro;
}

public void setCobro(int cobro) {
    this.cobro = cobro;
}

public Curso getCurso() {
    return this.curso;
}

public void setCurso(Curso curso) {
    this.curso = curso;
}

public Instructor getInstructor() {
    return this.instructor;
}

public void setInstructor(Instructor instructor) {
    this.instructor = instructor;
}

public String mostrarInfo(){
    return "IdInstructor: " + getIdInscripcion() + "\nnombre:" + getNombre1() + "'nCobro: " + getCobro() + "\nCurso: " + getCurso() + "\nInstructor: " + getInstructor();
}
}
