package service;

public class Inscripcion {
    
    private int idInscripcion;
    private String nombre1;
    private int cobro;
    private int curso;
    private instructor Instructor;


public Inscripcion() {

}

public int getIdInscripcion() {
    return this.idInscripcion;
}

public void setIdInscripcion(int idInscripcion) {
    this.idInscripcion = idInscripcion;
}

public String getNombre1() {
    return this.nombre1;
}

public void setNombre1(String nombre1) {
    this.nombre1 = nombre1;
}

public int getCobro() {
    return this.cobro;
}

public void setCobro(int cobro) {
    this.cobro = cobro;
}

public int getCurso() {
    return this.curso;
}

public void setCurso(int curso) {
    this.curso = curso;
}
}
