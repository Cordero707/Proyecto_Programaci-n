package view;


import java.util.Scanner;

import model.Curso;
import model.Instructor;
import service.Inscripcion;

 

public class Menu {

    public static void main (String[] args) throws Exception {
        Scanner scan = new Scanner (System.in);

        Instructor instructor = null;
        Curso curso = null;
        Inscripcion inscripcion = null;

        


        int opcion = 0;
        String menu = ("****************************************Menu Principal****************************************\n\n\n1. Guardar Curso\n2. Guardar Instructor\n3. Guardar Inscripcion\n4. Mostrar Curso\n5. Mostrar Instructor\n6. Mostrar Inscripcion\n7. Salir");
        String subMenu = "****************Sub-Menu****************\n1. Agregar\n2. Modificar";
        int opcionSubMenu = '0';

        while (opcion != 7){


            System.out.println(menu);
             opcion = scan.nextInt();
        

        switch (opcion) {
            case 1:

                System.out.println(subMenu);
                opcionSubMenu = scan.nextInt();
                switch (opcionSubMenu) {

                    case 1:
                        curso = new Curso();

                    int idCurso;
                    String descripcion;
                    int horas;
                    int precio;

                System.out.println("\nIndique el ID del curso");
                idCurso = scan.nextInt();

                System.out.println("Indique la descripción del curso");
                descripcion = scan.next();

                System.out.println("Indique las horas totales del curso");
                horas = scan.nextInt();

                System.out.println("Indique el precio del curso");
                precio = scan.nextInt();

                curso.setIdICurso(idCurso);
                curso.setDescripcion(descripcion);
                curso.setHoras(horas);
                curso.setPrecio(precio);
                
                break;

            case 2:
                if (curso != null) {
                    System.out.println("Ingrese el nuevo ID del curso");
                    idCurso = scan.nextInt();
                    System.out.println("Ingrese la nueva descripción del curso");
                    descripcion = scan.next();
                    System.out.println("Ingrese las nuevas horas totales del curso");
                    horas = scan.nextInt();
                    System.out.println("Ingrese el nuevo precio del curso");
                    precio = scan.nextInt();

                    curso.setIdICurso(idCurso);
                    curso.setDescripcion(descripcion);
                    curso.setHoras(horas);
                    curso.setPrecio(precio);
                }
                break;

                default:
                    break;
        
                }
                break;

                switch (opcion) {
            case 1:

                System.out.println(subMenu);
                opcionSubMenu = scan.nextInt();
                switch (opcionSubMenu) {

                case 2:

                instructor = new Instructor();
                int idInstructor;
                String nombre;
                int edad;
                boolean activo;

                System.out.println("Indique el ID del instructor");
                idInstructor = scan.nextInt();

                System.out.println("Indique el instructor del instructor");
                nombre = scan.next();

                System.out.println("Indique la edad del instructor");
                edad = scan.nextInt();

                System.out.println("Indique si el instructor esta activo (true/false)");
                activo = scan.nextBoolean();

                instructor.setIdInstructor(idInstructor);
                instructor.setNombre(nombre);
                instructor.setEdad(edad);
                instructor.setActivo(activo);

                break;

            case 2:

                if (instructor != null) {
                    System.out.println("Ingrese el nuevo ID del instructor");
                    idInstructor = scan.nextInt();
                    System.out.println("Ingrese el nuevo nombre del instructor");
                    nombre = scan.next();
                    System.out.println("Ingrese la nueva edad del instructor");
                    edad = scan.nextInt();
                    System.out.println("Indique otra vez si el instructor esta activo (true/false)");
                    activo = scan.nextBoolean();

                    instructor.setIdInstructor(idInstructor);
                    instructor.setNombre(nombre);
                    instructor.setEdad(edad);
                    instructor.setActivo(activo);

            }
                break;

                default:
                    break;
        
                }
                break;

                case 3:
                    if (curso != null & instructor != null) {
                        
                    
                inscripcion = new Inscripcion();
                int idInscripcion;
                String nombre1;
                int cobro;

                System.out.println("Indique el ID de la inscripción");
                idInscripcion = scan.nextInt();

                System.out.println("Indique el nombre de la persona que hace la inscripcion");
                nombre1 = scan.next();

                System.out.println("Indique el monto total de la inscripcion");
                cobro = scan.nextInt();

                inscripcion.setIdInscripcion(idInscripcion);
                inscripcion.setNombre1(nombre1);
                inscripcion.setCobro(cobro);
                    } else {

                        System.out.println("Ingrese a la opción 1 y 2 primero!!");

                    }

                break;

                case 4:
                   if (curso!= null) {
                        System.out.println("Mostrar Información del Curso");
                        System.out.println("La info del curso es" + curso.mostrarInfor());

                   } else {
                    System.out.println("No hay información para mostrar");
                   }

                   
                    break;


                case 5:
                   if (instructor!= null) {
                        System.out.println("Mostrar Información del Instructor");
                        System.out.println("La info del instructor es" + instructor.mostrarInfo());

                   } else {
                    System.out.println("No hay información para mostrar");
                   }

                   
                    break;

                case 6:
                   if (inscripcion!= null) {
                        System.out.println("Mostrar Información del Inscripción");
                        System.out.println("La info del inscripción es" + inscripcion.mostrarInfo());

                   } else {
                    System.out.println("No hay información para mostrar");
                   }

                   
                    break;

                case 7:

                System.out.println( "Saliendo del sistema...");

                    break;

            default:
                System.out.println("La opcion que indico no es correcta, por favor intente nuevamente");
                break;
        }
    } 

    scan.close();

    
    }
    }}